function over(obj) {
	obj.src="media/banana.png";
}
function out(obj) {
	obj.src="media/apple.png";
}
